﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using crossblog.Controllers;
using crossblog.Domain;
using crossblog.Model;
using crossblog.Repositories;
using FizzWare.NBuilder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using Xunit;

namespace crossblog.tests.Controllers
{
    public class CommentsControllerTest
    {

        private ArticlesController _articlesController;
        private CommentsController _commentsController;

        private Mock<IArticleRepository> _articleRepositoryMock = new Mock<IArticleRepository>();
        private Mock<ICommentRepository> _commentsRepositoryMock = new Mock<ICommentRepository>();

        public CommentsControllerTest()
        {
            _commentsController = new CommentsController(_articleRepositoryMock.Object, _commentsRepositoryMock.Object);
        }


        [Fact]
        public async Task Get_NotFound()
        {
            // Arrange
            _commentsRepositoryMock.Setup(m => m.GetAsync(1)).Returns(Task.FromResult<Comment>(null));

            // Act
            var result = await _commentsController.Get(1);

            // Assert
            Assert.NotNull(result);

            var objectResult = result as NotFoundResult;
            Assert.NotNull(objectResult);
        }

        [Fact]
        public async Task Get_ReturnItem()
        {
            // Arrange
            _articleRepositoryMock.Setup(m => m.GetAsync(1)).Returns(Task.FromResult<Article>(Builder<Article>.CreateNew().Build()));

            var commentsDbSetMock = Builder<Comment>.CreateListOfSize(3).Build().ToAsyncDbSetMock();
            _commentsRepositoryMock.Setup(m => m.Query()).Returns(commentsDbSetMock.Object);

            // Act
            var result = await _commentsController.Get(1);

            // Assert
            Assert.NotNull(result);

            var objectResult = result as OkObjectResult;
            Assert.NotNull(objectResult);

            var content = objectResult.Value as CommentListModel;
            Assert.NotNull(content);

        }


        [Fact]
        public async Task Get2_NotFound()
        {
            // Arrange
            _articleRepositoryMock.Setup(m => m.GetAsync(1)).Returns(Task.FromResult<Article>(null));

            // Act
            var result = await _commentsController.Get(1,1);

            // Assert
            Assert.NotNull(result);

            var objectResult = result as NotFoundResult;
            Assert.NotNull(objectResult);
        }

        [Fact]
        public async Task Get2_ReturnItem()
        {
            // Arrange
            _articleRepositoryMock.Setup(m => m.GetAsync(1)).Returns(Task.FromResult<Article>(Builder<Article>.CreateNew().Build()));

            var commentsDbSetMock = Builder<Comment>.CreateListOfSize(3).Build().ToAsyncDbSetMock();
            _commentsRepositoryMock.Setup(m => m.Query()).Returns(commentsDbSetMock.Object);

            // Act
            var result = await _commentsController.Get(1, 1);

            // Assert
            Assert.NotNull(result);

            //var objectResult = result as OkObjectResult;
            //Assert.NotNull(objectResult);

            //var content = objectResult.Value as CommentModel;
            //Assert.NotNull(content);
        }

        [Fact]
        public async Task Post_NotFound()
        {
            // Arrange
            _articleRepositoryMock.Setup(m => m.GetAsync(1)).Returns(Task.FromResult<Article>(null));

            // Act
            var dat = new CommentModel();
            var result = await _commentsController.Post(1, dat);

            // Assert
            Assert.NotNull(result);

            var objectResult = result as NotFoundResult;
            Assert.NotNull(objectResult);
        }

        [Fact]
        public async Task Post_NotFound2()
        {
            // Arrange
            _articleRepositoryMock.Setup(m => m.GetAsync(1)).Returns(Task.FromResult<Article>(Builder<Article>.CreateNew().Build()));

            var comment = new Comment
            {
                Id=1,
                Email = "test@yeaaa.com",
                Title = "wooohooo",
                Content = "this a a comment",
                Date = DateTime.UtcNow,
                Published = true
            };
            _commentsRepositoryMock.Setup(c => c.InsertAsync(comment));

            // Act
            var model = new CommentModel
            {
                Email = comment.Email,
                Title = comment.Title,
                Content = comment.Content,
                Date = DateTime.UtcNow,
                Published = comment.Published
            };
            var result = await _commentsController.Post(1, model);

            // Assert
            Assert.NotNull(result);

            var objectResult = result as CreatedResult;
            Assert.NotNull(objectResult);

        }


    }

}
